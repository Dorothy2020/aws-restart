print("Count to 10!")
for x in range (0, 11):
    print(x)